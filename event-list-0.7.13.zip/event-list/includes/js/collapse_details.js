eventlistMap=Array();
jQuery(document).ready(function(){
	if(elGoogleMapsKey!=undefined && elGoogleMapsKey!=""){eventlistAddScript('https://maps.googleapis.com/maps/api/js?key='+elGoogleMapsKey+'&callback=eventlistInit');}
});
function eventlistInit(){
	if(typeof eventlistKey!=='undefined'){toggle_event_details(eventlistKey);}
}
function toggle_event_details(event_id) {
	var details_div = document.getElementById('event-details-'.concat(event_id));
	var details_button = document.getElementById('event-detail-a'.concat(event_id));
	if (details_div.style.display == 'block') {
		details_div.style.display = 'none';
		details_button.innerHTML = el_show_details_text;
	}
	else {
		details_div.style.display = 'block';
		details_button.innerHTML = el_hide_details_text;
		if(typeof eventlistMap[event_id]==='undefined') {
			var eventlistCo=jQuery('#eventlistMap'+event_id).attr("eventlist");
			if(eventlistCo!=undefined){
				var eventlistPar=eventlistCo.split(";;");
				var eventlist=Array();
				if (eventlistPar.length>0) {
			  	for (i=0;i<eventlistPar.length;i++) {
			  	  if (eventlistPar[i].length>1) {
			  	  	var easyview_variable=eventlistPar[i].split("==");
			  	  	switch (true){
			  	  		case easyview_variable[0]=="location":
			  	  		case easyview_variable[0]=="locationaddress":
			  	  		case easyview_variable[0]=="locationiconpath":
			  	  		case easyview_variable[0]=="parking":
			  	  		case easyview_variable[0]=="parkingaddress":
			  	  		case easyview_variable[0]=="parkingiconpath":
			  	  			eventlist[easyview_variable[0]]=easyview_variable[1];
			  	  			break;
			  	  		case easyview_variable[0]=="zoom":
			  	  			eventlist[easyview_variable[0]]=parseInt(easyview_variable[1]);
			  	  			break;
			  	  		default:
			  	  			eventlist[easyview_variable[0]]=parseFloat(easyview_variable[1]);
			  	  	}
			  	  }
			  	}
			  }
				mapOptions={zoom:eventlist['zoom']};
				eventlistMap[event_id]=new google.maps.Map(jQuery('#eventlistMap'+event_id).get(0),mapOptions);
				jQuery(document).bind('webkitfullscreenchange mozfullscreenchange fullscreenchange', function() {
					google.maps.event.addListenerOnce(eventlistMap[event_id],'idle',function(){
						eventlistCenterRes=eventlistCenterFun(eventlist['locationlatitude'],eventlist['locationlongitude'],eventlist['parkinglatitude'],eventlist['parkinglongitude']);
						eventlistMap[event_id].setCenter({lat:eventlistCenterRes['Lat'],lng:eventlistCenterRes['Lon']});
					});
				});
				if(typeof eventlist['parkinglatitude']!=='undefined'){
					eventlistCenterRes=eventlistCenterFun(eventlist['locationlatitude'],eventlist['locationlongitude'],eventlist['parkinglatitude'],eventlist['parkinglongitude']);
					eventlistMap[event_id].setCenter({lat:eventlistCenterRes['Lat'],lng:eventlistCenterRes['Lon']});
					if (eventlist['parking']=="") {
						eventlistParking=eventlist['parkingaddress'];
					}else{
						eventlistParking=eventlist['parking']+'\n'+eventlist['parkingaddress'];
					}
					var locationaddress = new google.maps.Marker({map:eventlistMap[event_id],position:{lat:eventlist['parkinglatitude'],lng:eventlist['parkinglongitude']},icon:eventlist['parkingiconpath'],title:eventlistParking});
				}
				if(typeof eventlist['locationlatitude']!=='undefined'){
					eventlistCenterRes=eventlistCenterFun(eventlist['locationlatitude'],eventlist['locationlongitude'],eventlist['parkinglatitude'],eventlist['parkinglongitude']);
					eventlistMap[event_id].setCenter({lat:eventlistCenterRes['Lat'],lng:eventlistCenterRes['Lon']});
					if (eventlist['location']=="") {
						eventlistlocation=eventlist['locationaddress'];
					}else{
						eventlistlocation=eventlist['location']+'\n'+eventlist['locationaddress']
					}
					var locationaddress = new google.maps.Marker({map:eventlistMap[event_id],position:{lat:eventlist['locationlatitude'],lng:eventlist['locationlongitude']},icon:eventlist['locationiconpath'],title:eventlistlocation});
				}
			}
		}
	}
	return false;
}
function eventlistCenterFun(locationlatitude,locationlongitude,parkinglatitude,parkinglongitude){
	eventlistCenter=Array();
	if(locationlatitude!=0 && parkinglatitude!=0){
		eventlistCenter['Lat']=(locationlatitude+parkinglatitude)/2;
		eventlistCenter['Lon']=(locationlongitude+parkinglongitude)/2;
	}else{
		if(locationlatitude!=0 && parkinglatitude==0){
			eventlistCenter['Lat']=locationlatitude;
			eventlistCenter['Lon']=locationlongitude;
		}else{
			if(locationlatitude==0 && parkinglatitude!=0){
				eventlistCenter['Lat']=parkinglatitude;
				eventlistCenter['Lon']=parkinglongitude;
			}
		}
	}
	return eventlistCenter;
}
function eventlistAddScript(url){
  var script   = document.createElement("script");
  script.type  = "text/javascript";
  script.src   = url;
  script.async="async";
  script.defer="defer";
  document.body.appendChild(script);
  document.body.removeChild(document.body.lastChild);
  return true;
};