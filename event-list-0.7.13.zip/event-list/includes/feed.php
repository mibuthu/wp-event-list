<?php
if(!defined('ABSPATH')) {
	exit;
}
require_once(EL_PATH.'includes/db.php');
require_once(EL_PATH.'includes/options.php');
require_once(EL_PATH.'includes/categories.php');

// This class handles rss feeds
class EL_Feed {

	private static $instance;
	private $db;
	private $options;
	private $categories;
	private function easydebugcollect($easydebugdes,$easydebugval){
	  $easydebug=new easydebug;
	  $easydebug->collect($easydebugdes,$easydebugval);
	}
	public static function &get_instance() {
		// Create class instance if required
		if(!isset(self::$instance)) {
			self::$instance = new self();
		}
		// Return class instance
		return self::$instance;
	}

	private function __construct() {
		$this->db = EL_Db::get_instance();
		$this->options = EL_Options::get_instance();
		$this->categories = EL_Categories::get_instance();
		$this->init();
	}

	public function init() {
		add_feed($this->options->get('el_feed_name'), array(&$this, 'print_eventlist_feed'));
		if($this->options->get('el_head_feed_link')) {
			add_action('wp_head', array(&$this, 'print_head_feed_link'));
		}
	}

	public function print_head_feed_link() {
		echo '<link rel="alternate" type="application/rss+xml" title="'.get_bloginfo_rss('name').' &raquo; '.$this->options->get('el_feed_description').'" href="'.$this->eventlist_feed_url().'" />';
	}

	public function print_eventlist_feed() {
		if(strpos(get_bloginfo('language'),'-')===false){
			setlocale(LC_TIME,get_bloginfo('language').'_'.strtoupper(get_bloginfo('language')));
		}else{
			setlocale(LC_TIME,str_replace('-','_',get_bloginfo('language')));
		}
		$eventlistPagePath=$this->options->get('el_page_path');	
		if(substr($eventlistPagePath,0,4)=='http'){
			$eventlistPagePath=$eventlistPagePath;
		}else{
			$eventlistPagePath=get_site_url().$eventlistPagePath;
		}
		header('Content-Type: '.feed_content_type('rss2').'; charset='.get_option('blog_charset'), true);
		$eventlistCatFilter="";
		$eventlistCatDelimiter="";
		$eventlistCat=$this->options->get("el_feed_category");
		if(is_array($eventlistCat)){
			foreach($eventlistCat as $key=>$value){
				$eventlistCatFilter.=$eventlistCatDelimiter.$key;
				$eventlistCatDelimiter=",";
			}
		}
		if($eventlistCatFilter==""){$eventlistCatFilter=NULL;}
		$events = $this->db->get_events(($this->options->get('el_feed_upcoming_only') ? 'upcoming' : null),$eventlistCatFilter, 0, array('start_date ASC', 'time ASC', 'end_date ASC'));
		// Print feeds
		
		print '<?xml version="1.0" encoding="'.get_option('blog_charset').'"?>';?>
		<rss version="2.0"
			xmlns:content="http://purl.org/rss/1.0/modules/content/"
			xmlns:wfw="http://wellformedweb.org/CommentAPI/"
			xmlns:dc="http://purl.org/dc/elements/1.1/"
			xmlns:atom="http://www.w3.org/2005/Atom"
			xmlns:sy="http://purl.org/rss/1.0/modules/syndication/"
			xmlns:slash="http://purl.org/rss/1.0/modules/slash/"
		>
		<channel>
			<title><?php print get_bloginfo_rss('name'); ?></title>
			<atom:link href="<?php print $this->eventlist_feed_url(); ?>" rel="self" type="application/rss+xml" />
			<link><?php print get_bloginfo_rss('url'); ?></link>
			<description><?php print $this->options->get('el_feed_description'); ?></description>
			<lastBuildDate><?php print mysql2date('D, d M Y H:i:s +0000', get_lastpostmodified('GMT'), false); ?></lastBuildDate>
			<language><?php print substr(get_bloginfo('language'),0,2); ?></language>
			<sy:updatePeriod><?php print apply_filters('rss_update_period', 'hourly'); ?></sy:updatePeriod>
			<sy:updateFrequency><?php print apply_filters('rss_update_frequency', '1'); ?></sy:updateFrequency>
		<?php print do_action('rss2_head'); 
		if(!empty($events)) {
			$count=0;
			foreach ($events as $event) {
				$elTime="";
				if(isset($event->time) && !empty($event->time)){$elTime=' '.$event->time;} ?>
				<item>
					<title><<?php print '!['; ?>CDATA[<em><?php print $this->format_date($event->start_date, $event->end_date).$elTime; ?></em><br><?php print $this->sanitize_feed_text($event->title); ?>]]></title>
					<pubDate><?php print date(DATE_RSS,intval(strtotime(date('Y-m-d'))-$count*60-60)); ?></pubDate>
					<?php // Feed categories
					$cats = $this->categories->convert_db_string($event->categories, 'name_array');
					foreach ($cats as $cat) { ?>
						<category><?php print $this->sanitize_feed_text($cat); ?></category>
					<?php }
					?><description><<?php print '!['; ?>CDATA[<?php
					if(isset($event->location) && !empty($event->location)){?><em><?php print $event->location; ?></em>:<br> <?php }
					if(isset($event->locationaddress) && !empty($event->locationaddress)){print $event->locationaddress;}
					if(isset($event->parking) && !empty($event->parking)){?><br><em><?php print $event->parking; ?></em>:<br><?php }
					if(isset($event->parkingaddress) && !empty($event->parkingaddress)){print $event->parkingaddress;}
					if(isset($event->contactphone) && !empty($event->contactphone)){?> <br><em><?php print __('Phone','event-list'); ?></em>: <?php print $event->contactphone;}
					if(isset($event->contactmobile) && !empty($event->contactmobile)){?><br><em><?php print __('Mobile','event-list'); ?></em>: <?php print $event->contactmobile;}
					if(isset($event->contactemail) && !empty($event->contactemail)){?><br><em><?php print __('Email','event-list'); ?></em>: <a href="mailto:<?php print $event->contactemail; ?>"><?php print $event->contactemail; ?></a><?php }
					if(isset($event->contacturl) && !empty($event->contacturl)){
						if(substr($event->contacturl,0,4)=="http"){
							?><br><em><?php print __('Website','event-list'); ?></em>: <a href="<?php print $event->contacturl; ?>"><?php print $event->contacturl; ?></a><?php
						}else{
							?><br><em><?php print __('Website','event-list'); ?></em>: <a href="<?php print get_site_url().$event->contacturl; ?>"><?php print get_site_url().$event->contacturl; ?></a><?php
						}
					}
					if(isset($event->details) && !empty($event->details)){?><br><?php print $elRes.$event->details;}?>
					]]></description>
					<link><?php print $eventlistPagePath.'?event_id1='.$event->id; ?></link>
					<guid><?php print $eventlistPagePath.'?count='.$count; ?></guid>
				</item><?php
				$count++;
			}
		} 
		?></channel></rss><?php
	}
	public function eventlist_feed_url() {
		if(get_option('permalink_structure')) {
			$feed_link = get_bloginfo('url').'/feed/';
		}
		else {
			$feed_link = get_bloginfo('url').'/?feed=';
		}
		return $feed_link.$this->options->get('el_feed_name');
	}

	public function update_feed_rewrite_status() {
		$feeds = array_keys((array)get_option('rewrite_rules'), 'index.php?&feed=$matches[1]');
		$feed_rewrite_status = (0 < count(preg_grep('@[(\|]'.$this->options->get('el_feed_name').'[\|)]@', $feeds))) ? true : false;
		if('1' == $this->options->get('el_enable_feed') && !$feed_rewrite_status) {
			// add eventlist feed to rewrite rules
			flush_rewrite_rules(false);
		}
		elseif('1' != $this->options->get('el_enable_feed') && $feed_rewrite_status) {
			// remove eventlist feed from rewrite rules
			flush_rewrite_rules(false);
		}
	}

	private function feed_description(&$event) {
		return $this->format_date($event->start_date, $event->end_date). (empty($event->time) ? '' : ' '.$this->sanitize_feed_text($event->time)).(empty($event->location) ? '' : ' - '.$this->sanitize_feed_text($event->location));
	}

	private function sanitize_feed_text($text) {
		return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
	}

	private function format_date($start_date, $end_date) {
		$startArray = explode("-", $start_date);
		$start_date = mktime(0,0,0,$startArray[1],$startArray[2],$startArray[0]);

		$endArray = explode("-", $end_date);
		$end_date = mktime(0,0,0,$endArray[1],$endArray[2],$endArray[0]);

		$event_date = '';

		if ($start_date == $end_date) {
			if ($startArray[2] == "00") {
				$start_date = mktime(0,0,0,$startArray[1],15,$startArray[0]);
				$event_date .= date_i18n("F, Y", $start_date);
				return $event_date;
			}
			$event_date .= date_i18n("j F Y", $start_date);
			return $event_date;
		}

		if ($startArray[0] == $endArray[0]) {
			if ($startArray[1] == $endArray[1]) {
				$event_date .= date_i18n("j", $start_date).' '.__('to','event-list').' '.date_i18n("j F Y", $end_date);
				return $event_date;
			}
			$event_date .= date_i18n("j", $start_date).' '.__('to','event-list').' '.date_i18n("j F Y", $end_date);
			return $event_date;

		}

		$event_date .= date_i18n("j F Y", $start_date).' '.__('to','event-list').' '.date_i18n("j F Y", $end_date);
		return $event_date;
	}
}
?>