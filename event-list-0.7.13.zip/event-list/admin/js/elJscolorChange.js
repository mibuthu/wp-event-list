function update(jscolor){
	var elID="#"+jQuery(event.currentTarget.activeElement).attr("id");
	jQuery(elID+'box').css("background-color","#"+jQuery(elID).val());
	jQuery(elID).attr('value',jQuery("#el_color_button").val());
}