var eventlistGeocoder;
var eventlistMap;
jQuery(document).ready(function(){
	if(elGoogleMapsKey!=undefined && elGoogleMapsKey!=""){eventlistAddScript('https://maps.googleapis.com/maps/api/js?key='+elGoogleMapsKey+'&callback=eventlistInit');}
});
function eventlistInit() {
	if(jQuery("#zoom").val()==""){
		mapOptions={zoom:17};
		jQuery("#zoom").val(17);
	}else{
		mapOptions={zoom:parseInt(jQuery("#zoom").val())};
	}
	eventlistMap=new google.maps.Map(jQuery('#eventlistMap').get(0),mapOptions);
	eventlistMap.addListener('zoom_changed',function(){jQuery("#zoom").val(eventlistMap.getZoom());});
	jQuery(document).bind('webkitfullscreenchange mozfullscreenchange fullscreenchange', function() {
		google.maps.event.addListenerOnce(eventlistMap[event_id],'idle',function(){
			eventlistCenterRes=eventlistCenterCalc(parseFloat(jQuery("#locationlatitude").val()),parseFloat(jQuery("#locationlongitude").val()),parseFloat(jQuery("#parkinglatitude").val()),parseFloat(jQuery("#parkinglongitude").val()));
			eventlistMap.setCenter({lat:eventlistCenterRes['Lat'],lng:eventlistCenterRes['Lon']});
		});
	});
  eventlistGeocodeAddress('parking','parkingaddress','parkingaddressold','parkinglatitude','parkinglongitude',jQuery("#parkingiconpath").val());
  eventlistGeocodeAddress('location','locationaddress','locationaddressold','locationlatitude','locationlongitude',jQuery("#locationiconpath").val());
}
function eventlistCenterCalc(locationlatitude,locationlongitude,parkinglatitude,parkinglongitude){
	eventlistCenter=Array();
	if(locationlatitude!=0 && parkinglatitude!=0){
		eventlistCenter['Lat']=(locationlatitude+parkinglatitude)/2;
		eventlistCenter['Lon']=(locationlongitude+parkinglongitude)/2;
	}else{
		if(locationlatitude!=0 && parkinglatitude==0){
			eventlistCenter['Lat']=locationlatitude;
			eventlistCenter['Lon']=locationlongitude;
		}else{
			if(locationlatitude==0 && parkinglatitude!=0){
				eventlistCenter['Lat']=parkinglatitude;
				eventlistCenter['Lon']=parkinglongitude;
			}
		}
	}
	return eventlistCenter;
}
function eventlistGeocodeAddress(eventlistType,eventlistAddress,eventlistAddressOld,eventlistLatitude,eventlistLongitude,eventlistIconPath) {
	if(jQuery("#"+eventlistAddress).val()!=""){
		if(parseFloat(jQuery("#"+eventlistLatitude).val())==0){
			eventlistGeocoder=new google.maps.Geocoder();
		  eventlistGeocoder.geocode({'address':jQuery("#"+eventlistAddress).val()},function(results,status) {
		    if (status == 'OK') {
		      eventlistMap.setCenter(results[0].geometry.location);
		      jQuery("#"+eventlistLatitude).val(results[0].geometry.location.lat());
		  		jQuery("#"+eventlistLongitude).val(results[0].geometry.location.lng());
		  		if (jQuery("#"+eventlistType).val()==""){var eventlistTitle=jQuery("#"+eventlistAddress).val();}else{var eventlistTitle=jQuery("#"+eventlistType).val()+'\n'+jQuery("#"+eventlistAddress).val();}
		      var locationaddress = new google.maps.Marker({map:eventlistMap,draggable:true,position:results[0].geometry.location,icon:eventlistIconPath,title:eventlistTitle}).addListener('dragend',function(evt){  
		        jQuery("#"+eventlistLatitude).val(evt.latLng.lat());
		        jQuery("#"+eventlistLongitude).val(evt.latLng.lng());
		      });
		    } else {
		      alert('Geocode of '+eventlistAddress+' was not successful for the following reason: ' + status);
		    }
		  });
		}else{
			eventlistCenterRes=eventlistCenterCalc(parseFloat(jQuery("#locationlatitude").val()),parseFloat(jQuery("#locationlongitude").val()),parseFloat(jQuery("#parkinglatitude").val()),parseFloat(jQuery("#parkinglongitude").val()));
			eventlistMap.setCenter({lat:eventlistCenterRes['Lat'],lng:eventlistCenterRes['Lon']});
			if (jQuery("#"+eventlistType).val()==""){var eventlistTitle=jQuery("#"+eventlistAddress).val();}else{var eventlistTitle=jQuery("#"+eventlistType).val()+'\n'+jQuery("#"+eventlistAddress).val();}
			var locationaddress = new google.maps.Marker({map:eventlistMap,draggable:true,position:{lat:parseFloat(jQuery("#"+eventlistLatitude).val()),lng:parseFloat(jQuery("#"+eventlistLongitude).val())},icon:eventlistIconPath,title:eventlistTitle}).addListener('dragend',function(evt){  
		    jQuery("#"+eventlistLatitude).val(evt.latLng.lat());
		    jQuery("#"+eventlistLongitude).val(evt.latLng.lng());
		  });
		}
	}
}
function eventlistAddScript(url){
  var script   = document.createElement("script");
  script.type  = "text/javascript";
  script.src   = url;
  script.async="async";
  script.defer="defer";
  document.body.appendChild(script);
  document.body.removeChild(document.body.lastChild);
  return true;
};