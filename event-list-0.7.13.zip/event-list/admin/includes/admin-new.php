<?php
if(!defined('ABSPATH')) {
	exit;
}

require_once(EL_PATH.'includes/db.php');
require_once(EL_PATH.'includes/options.php');
require_once(EL_PATH.'includes/categories.php');
require_once(EL_PATH.'includes/feed.php');

// This class handles all data for the admin new event page
class EL_Admin_New {
	private static $instance;
	private $db;
	private $options;
	private $categories;
	private $id;
	private $is_new;
	private $is_duplicate;

	public static function &get_instance() {
		// Create class instance if required
		if(!isset(self::$instance)) {
			self::$instance = new EL_Admin_New();
		}
		// Return class instance
		return self::$instance;
	}

	private function __construct() {
		// check used get parameters
		$action = isset($_GET['action']) ? sanitize_key($_GET['action']) : '';
		$this->id = isset($_GET['id']) ? intval($_GET['id']) : 0;

		$this->db = &EL_Db::get_instance();
		$this->options = &EL_Options::get_instance();
		$this->categories = &EL_Categories::get_instance();
		$this->is_new = !('edit' == $action || 'added' == $action || 'modified' == $action);
		$this->is_duplicate = $this->is_new && '' != $action && 0 < $this->id;
	}

	public function show_new() {
		if(!current_user_can('edit_posts')) {
			wp_die(__('You do not have sufficient permissions to access this page.'));
		}
		$out = '<div class="wrap">
				<div id="icon-edit-pages" class="icon32"><br /></div><h2>'.__('Add New Event','event-list').'</h2>';
		if($this->is_duplicate) {
			$out .= '<span style="color:silver">('.sprintf(__('Duplicate of event id:%d','event-list'), $this->id).')</span>';
		}
		$out .= $this->edit_event();
		$out .= '</div>';
		echo $out;
	}

	public function embed_new_scripts() {
		wp_enqueue_script('jquery');
		wp_enqueue_script('jquery-ui-datepicker');
		wp_enqueue_script('link');
		wp_enqueue_script('eventlist_admin_new_js', EL_URL.'admin/js/admin_new.js');
		wp_enqueue_script('eventlist_admin_map_js', EL_URL.'admin/js/admin_map.js');
		wp_enqueue_script('eventlist_admin_color_js', EL_URL.'admin/js/elJscolor.js');
		wp_enqueue_script('eventlist_admin_colorchange_js', EL_URL.'admin/js/elJscolorChange.js');
		// TODO: wp_localize_jquery_ui_datepicker is available since wordpress version 4.6.0.
		//       For compatibility to older versions the function_exists test was added, this test can be removed again in a later version.
		if(function_exists("wp_localize_jquery_ui_datepicker")) {
			wp_localize_jquery_ui_datepicker();
		}
		wp_enqueue_style('eventlist_admin_date', EL_URL.'admin/css/admin_date.css');
		wp_enqueue_style('eventlist_admin_new', EL_URL.'admin/css/admin_new.css');
		// add the jquery-ui style "smooth" (see https://jqueryui.com/download/) (required for the xwp datepicker skin)
		wp_enqueue_style('eventlist_jqueryui', EL_URL.'admin/css/jquery-ui.min.css');
		// add the xwp datepicker skin (see https://github.com/xwp/wp-jquery-ui-datepicker-skins)
		wp_enqueue_style('eventlist_datepicker', EL_URL.'admin/css/jquery-ui-datepicker.css');
	}

	public function edit_event() {
		$dateformat = $this->get_event_dateformat();
		if($this->is_new && !$this->is_duplicate) {
			// set next day as date
			$start_date = current_time('timestamp')+86400; // next day (86400 seconds = 1*24*60*60 = 1 day);
			$end_date = $start_date;
		}
		else {
			// set event data and existing date
			$event = $this->db->get_event($this->id);
			$start_date = strtotime($event->start_date);
			$end_date = strtotime($event->end_date);
		}
		// Add required data for javascript in a hidden field
		$json = json_encode(array('el_date_format'   => $this->datepicker_format($dateformat),
		                          'el_start_of_week' => get_option('start_of_week')));
		$out = '<script type="text/javascript">var elGoogleMapsKey="'.$this->options->get('el_google_maps_key').'";</script>';
		$out .= '
				<form method="POST" action="'.add_query_arg('noheader', 'true', '?page=el_admin_main').'">';
		$out .= "
				<input type='hidden' id='json_for_js' value='".$json."' />"; // single quote required for value due to json layout
		// TODO: saving changed metabox status and order is not working yet
		$out .= wp_nonce_field('autosavenonce', 'autosavenonce', false, false);
		$out .= wp_nonce_field('closedpostboxesnonce', 'closedpostboxesnonce', false, false);
		$out .= wp_nonce_field('meta-box-order-nonce', 'meta-box-order-nonce', false, false);
		$out .= '
				<div id="poststuff">
				<div id="post-body" class="metabox-holder columns-2">
				<div id="post-body-content">';
		if($this->is_new) {
			$out .= '
					<input type="hidden" name="action" value="new" />';
		}
		else {
			$out .= '
					<input type="hidden" name="action" value="edited" />
					<input type="hidden" name="id" value="'.$this->id.'" />';
		}
		$elDateColor=Array(1=>"",2=>"",3=>"",4=>"",5=>"");
		if(isset($event->datecolor) && is_numeric($event->datecolor)){$elDateColor[$event->datecolor]=' checked="checked"';}else{$elDateColor[1]=' checked="checked"';}
		$out .= '
					<input type="hidden" class="text" name="zoom" id="zoom" value="'.str_replace('"', '&quot;', isset($event->zoom) ? $event->zoom : '').'" />
					<input type="hidden" class="text" name="locationaddressold" id="locationaddressold" value="'.str_replace('"', '&quot;', isset($event->locationaddress) ? $event->locationaddress : '').'" />
					<input type="hidden" class="text" name="locationlatitude" id="locationlatitude" value="'.str_replace('"', '&quot;', isset($event->locationlatitude) ? $event->locationlatitude : '').'" />
					<input type="hidden" class="text" name="locationlongitude" id="locationlongitude" value="'.str_replace('"', '&quot;', isset($event->locationlongitude) ? $event->locationlongitude : '').'" />
					<input type="hidden" class="text" name="locationiconpath" id="locationiconpath" value="'.EL_URL.'includes/images/location.png'.'" />
					<input type="hidden" class="text" name="parkingaddressold" id="parkingaddressold" value="'.str_replace('"', '&quot;', isset($event->parkingaddress) ? $event->parkingaddress : '').'" />
					<input type="hidden" class="text" name="parkinglatitude" id="parkinglatitude" value="'.str_replace('"', '&quot;', isset($event->parkinglatitude) ? $event->parkinglatitude : '').'" />
					<input type="hidden" class="text" name="parkinglongitude" id="parkinglongitude" value="'.str_replace('"', '&quot;', isset($event->parkinglongitude) ? $event->parkinglongitude : '').'" />
					<input type="hidden" class="text" name="parkingiconpath" id="parkingiconpath" value="'.EL_URL.'includes/images/parking.png'.'" />
					<table class="form-table">
					<tr>
						<th><label>'.__('Date color','event-list').'</label></th>
						<td>
							<div id="elNewDateBox" class="elNewDateBox" style="background-color:#fff;padding:20px;width:268px;height:70px;">'.
								$this->show_text_date(1,$this->options->get('el_color_button1'),$elDateColor[1]).
								$this->show_text_date(2,$this->options->get('el_color_button2'),$elDateColor[2]).
								$this->show_text_date(3,$this->options->get('el_color_button3'),$elDateColor[3]).
								$this->show_text_date(4,$this->options->get('el_color_button4'),$elDateColor[4]).
								$this->show_text_date(5,$this->options->get('el_color_button5'),$elDateColor[5]).
						  '</div>
					  </td>
					</tr>
					<tr>
						<th><label>'.__('Title','event-list').' ('.__('required','event-list').')</label></th>
						<td><input type="text" class="text form-required" name="title" id="title" value="'.str_replace('"', '&quot;', isset($event->title) ? $event->title : '').'" /></td>
					</tr>
					<tr>
						<th><label>'.__('Link','event-list').'</label></th>
						<td>'.$this->elSelectTab('linktab',isset($event->linktab) ? $event->linktab : '').'<input type="text" class="text form-required" name="link" id="link" value="'.str_replace('"', '&quot;', isset($event->link) ? $event->link : '').'" /></td>
					</tr>
					<tr>
						<th><label>'.__('Date','event-list').' ('.__('required','event-list').')</label></th>
						<td><span class="date-wrapper"><input type="text" class="text form-required" name="start_date" id="start_date" value="'.date('Y-m-d', $start_date).'" /><i class="dashicons dashicons-calendar-alt"></i></span>
							<span id="end_date_area"> - <span class="date-wrapper"><input type="text" class="text" name="end_date" id="end_date" value="'.date('Y-m-d', $end_date).'" /><i class="dashicons dashicons-calendar-alt"></i></span></span>
							<label><input type="checkbox" name="multiday" id="multiday" value="1" /> '.__('Multi-Day Event','event-list').'</label>
							<input type="hidden" id="sql_start_date" name="sql_start_date" value="" />
							<input type="hidden" id="sql_end_date" name="sql_end_date" value="" />
						</td>
					</tr>
					<tr>
						<th><label>'.__('Time','event-list').'</label></th>
						<td><input type="text" class="text" name="time" id="time" value="'.str_replace('"', '&quot;', isset($event->time) ? $event->time : '').'" /></td>
					</tr>
					<tr>
						<th><label>'.__('Location','event-list').'</label></th>
						<td><input type="text" class="text" name="location" id="location" value="'.str_replace('"', '&quot;', isset($event->location) ? $event->location : '').'" /></td>
					</tr>
					<tr>
						<th><label>'.__('Location address','event-list').'</label></th>
						<td><input type="text" class="text" name="locationaddress" id="locationaddress" value="'.str_replace('"', '&quot;', isset($event->locationaddress) ? $event->locationaddress : '').'" /></td>
					</tr>
					<tr>
						<th><label>'.__('Parking','event-list').'</label></th>
						<td><input type="text" class="text" name="parking" id="parking" value="'.str_replace('"', '&quot;', isset($event->parking) ? $event->parking : '').'" /></td>
					</tr>
					<tr>
						<th><label>'.__('Parking address','event-list').'</label></th>
						<td><input type="text" class="text" name="parkingaddress" id="parkingaddress" value="'.str_replace('"', '&quot;', isset($event->parkingaddress) ? $event->parkingaddress : '').'" /></td>
					</tr>';
					$eventlistGoogleKey=$this->options->get('el_google_maps_key');
					if(isset($eventlistGoogleKey) && $eventlistGoogleKey!=""){
						$out .= '
						<tr>
							<th><label>'.__('Map','event-list').'</label></th>
							<td><div id="eventlistMap" style="width:100%; height: 300px;"></div></td>
						</tr>';
					}
					$out .= '
					<tr>
						<th><label>'.__('Phone','event-list').'</label></th>
						<td><input type="text" class="text" name="contactphone" id="contactphone" value="'.str_replace('"', '&quot;', isset($event->contactphone) ? $event->contactphone : '').'" /></td>
					</tr>
					<tr>
						<th><label>'.__('Mobile','event-list').'</label></th>
						<td><input type="text" class="text" name="contactmobile" id="contactmobile" value="'.str_replace('"', '&quot;', isset($event->contactmobile) ? $event->contactmobile : '').'" /></td>
					</tr>
					<tr>
						<th><label>'.__('Email','event-list').'</label></th>
						<td><input type="text" class="text" name="contactemail" id="contactemail" value="'.str_replace('"', '&quot;', isset($event->contactemail) ? $event->contactemail : '').'" /></td>
					</tr>
					<tr>
						<th><label>'.__('Website','event-list').'</label></th>
						<td>'.$this->elSelectTab('contacturltab',isset($event->contacturltab) ? $event->contacturltab : '').'<input type="text" class="text" name="contacturl" id="contacturl" value="'.str_replace('"', '&quot;', isset($event->contacturl) ? $event->contacturl : '').'" /></td>
					</tr>
					<tr>
						<th><label>'.__('Details','event-list').'</label></th>
						<td>';
		$editor_settings = array('drag_drop_upload' => true,
		                         'textarea_rows' => 20);
		ob_start();
			wp_editor(isset($event->details) ? $this->elContent($event->details) : '', 'details', $editor_settings);
			$out .= ob_get_contents();
		ob_end_clean();
		$out .= '
						<p class="note">NOTE: In the text editor, use RETURN to start a new paragraph - use SHIFT-RETURN to start a new line.</p></td>
					</tr>
					</table>';
		$out .= '
				</div>
				<div id="postbox-container-1" class="postbox-container">
				<div id="side-sortables" class="meta-box-sortables ui-sortable">';
		add_meta_box('event-publish', __('Publish','event-list'), array(&$this, 'render_publish_metabox'), 'event-list');
		$metabox_args = isset($event->categories) ? array('event_cats' => $event->categories) : null;
		add_meta_box('event-categories', __('Categories','event-list'), array(&$this, 'render_category_metabox'), 'event-list', 'advanced', 'default', $metabox_args);
		ob_start();
			do_meta_boxes('event-list', 'advanced', null);
			$out .= ob_get_contents();
		ob_end_clean();
		$out .= '
				</div>
				</div>
				</div>
				</div>
				</form>';
		return $out;
	}
	public function show_text_date($elColorID,$elDateColor,$elDateColorChecked){
		return '
		 	<label class="elControl elControl--radio " style="cursor:pointer;display:inline-block;position:relative;height:4.4em;width:2.9em;margin-right:5px;left:10px;">
			 	<input type="radio" name="datecolor" value="'.$elColorID.'"'.$elDateColorChecked.' style="visibility:hidden;display:none;"/>
			 	<span class="elControl__indicator" >
					<div id="el_color_button'.$elColorID.'box" style="text-align:center;width: 3.2em;border-radius: 5px;background-color: rgb(230,230,230);background-color:#'.$elDateColor.';float:left;">
						<div style="font-size: 0.8em;text-transform: uppercase;">'.mysql2date('D',date('d')).'</div>
						<div style="font-size: 1.3em;font-weight: bold;line-height: 1em;margin-bottom: -0.2em;">'.mysql2date('d',date('d')).'</div>
						<div style="text-transform: uppercase;font-size: 1.0em;line-height: 1em;padding: 0.4em 0;">'.mysql2date('M',date('m')).'</div>
						<div style="font-size: 0.8em;line-height: 0.8em;letter-spacing: 0.1em;padding-bottom: 0.3em;">'.mysql2date('Y',date('y')).'</div>
					</div>
				</span>
			</label>';
	}
	public function elSelectTab($elTabId,$elTab) {
    $elTabSelect=Array();
    $elTabSelect['notab']='';
    $elTabSelect['tab']='';
    if(isset($elTab)){
	    switch($elTab){
	      case 'tab':
	        $elTabSelect['tab']='selected="selected"';
	        break;
	      default:
	      	$elTabSelect['notab']='selected="selected"';
	    }
	  }
    $elTabRes='<select name="'.$elTabId.'" id="'.$elTabId.'" class="elTab" style="height:25px;">';
    $elTabRes.='<option value="notab" '.$elTabSelect['notab'].'>Notab</option>';
	  $elTabRes.='<option value="tab" '.$elTabSelect['tab'].'>Tab</option>';
    $elTabRes.='</select>';
    return $elTabRes;
  }
	public function render_publish_metabox() {
		$button_text = $this->is_new ? __('Publish','event-list') : __('Update','event-list');
		$out = '<div class="submitbox">Afspraak gewijzigd: Eten Kis
				<div id="delete-action"><a href="?page=el_admin_main" class="submitdelete deletion">'.__('Cancel','event-list').'</a></div>
				<div id="publishing-action"><input type="submit" class="button button-primary button-large" name="publish" value="'.$button_text.'" id="publish"></div>
				<div class="clear"></div>
			</div>';
		echo $out;
	}

	public function render_category_metabox($post, $metabox) {
		$out = '
				<div id="taxonomy-category" class="categorydiv">
				<div id="category-all" class="tabs-panel">';
		$cat_array = $this->categories->get_cat_array('name', 'asc');
		if(empty($cat_array)) {
			$out .= __('No categories available.','event-list');
		}
		else {
			$out .= '
					<ul id="categorychecklist" class="categorychecklist form-no-clear">';
			$level = 0;
			$event_cats = $this->categories->convert_db_string($metabox['args']['event_cats'], 'slug_array');
			foreach($cat_array as $cat) {
				if($cat['level'] > $level) {
					//new sub level
					$out .= '
						<ul class="children">';
					$level++;
				}
				while($cat['level'] < $level) {
					// finish sub level
					$out .= '
						</ul>';
					$level--;
				}
				$level = $cat['level'];
				$checked = in_array($cat['slug'], $event_cats) ? 'checked="checked" ' : '';
				$out .= '
						<li id="'.$cat['slug'].'" class="popular-catergory">
							<label class="selectit">
								<input value="'.$cat['slug'].'" type="checkbox" name="categories[]" id="categories" '.$checked.'/> '.$cat['name'].'
							</label>
						</li>';
			}
			$out .= '
					</ul>';
		}

		$out .= '
				</div>';
		// TODO: Adding new categories in edit event form
		/*		<div id="category-adder" class="wp-hidden-children">
					<h4><a id="category-add-toggle" href="#category-add" class="hide-if-no-js">'.__('+ Add New Category','event-list').'</a></h4>
					<p id="category-add" class="category-add wp-hidden-child">
						<label class="screen-reader-text" for="newcategory">'.__('Category Name','event-list').'</label>
						<input type="text" name="newcategory" id="newcategory" class="form-required form-input-tip" value="" aria-required="true"/>
						<input type="button" id="category-add-submit" class="button category-add-submit" value="'.__('Add Category','event-list').'" />
					</p>
				</div>*/
		$out .= '
				<div id="category-manager">
					<a id="category-manage-link" href="?page=el_admin_categories">'.__('Goto Category Settings','event-list').'</a>
				</div>
				</div>';
		echo $out;
	}
	private function elContent($elContent){
	  $elTemp=str_replace('<br>&nbsp;<br>&nbsp;<br>',"\r\n\r\n\r\n",$elContent);
	  $elTemp=str_replace('<br>&nbsp;<br>',"\r\n\r\n",$elTemp);
	  $elTemp=str_replace('<br>',"\r\n",$elTemp);
	  return $elTemp;
	}
	private function get_event_dateformat() {
		if('' == $this->options->get('el_edit_dateformat')) {
			return __('Y/m/d');
		}
		else {
			return $this->options->get('el_edit_dateformat');
		}
	}

	/**
	 * Convert a date format to a jQuery UI DatePicker format
	 *
	 * @param string $format a date format
	 * @return string
	 */
	private function datepicker_format($format) {
		return str_replace(
        array(
            'd', 'j', 'l', 'z', // Day.
            'F', 'M', 'n', 'm', // Month.
            'Y', 'y'            // Year.
        ),
        array(
            'dd', 'd', 'DD', 'o',
            'MM', 'M', 'm', 'mm',
            'yy', 'y'
        ),
		  $format);
	}
}
?>