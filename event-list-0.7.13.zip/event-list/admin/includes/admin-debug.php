<?php
#require_once(EL_PATH.'admin/includes/admin-debug.php');
#elPrint(,);
	function elPrint($elLabel,$elPar){
		print '<br>'.$elLabel.'<br>';
		print_r($elPar);
		print '<br>------<br>';
	}
?>