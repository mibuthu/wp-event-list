<?php
if(!defined('WPINC')) {
	exit;
}

require_once(EL_PATH.'includes/options.php');

// This class handles general functions which can be used on different admin pages
class EL_Admin_Functions {
	private static $instance;
	private $options;
	private $elButtonReady=false;
	public static function &get_instance() {
		// Create class instance if required
		if(!isset(self::$instance)) {
			self::$instance = new EL_Admin_Functions();
		}
		// Return class instance
		return self::$instance;
	}

	private function __construct() {
		$this->options = &EL_Options::get_instance();
		$this->options->load_options_helptexts();
	}

	public function show_option_form($section) {
		$out = '
		<form method="post" action="options.php">
		';
		ob_start();
		settings_fields('el_'.$section);
		$out .= ob_get_contents();
		ob_end_clean();
		$out .= $this->show_option_table($section);
		ob_start();
		submit_button();
		$out .= ob_get_contents();
		ob_end_clean();
		$out .='
		</form>';
		return $out;
	}

	public function show_option_table($section) {
		$out = '
			<div class="el-settings">
			<table class="form-table">';
		foreach($this->options->options as $oname => $o) {
			if($o['section'] == $section) {
				if($this->elButtonReady && ($oname=="el_color_button1" || $oname=="el_color_button2" || $oname=="el_color_button3" || $oname=="el_color_button4" || $oname=="el_color_button5")){
				}else{
					$out .= '
						<tr>
							<th>';
					if($o['label'] != '') {
						$out .= '<label for="'.$oname.'">'.$o['label'].':</label>';
					}
					$out .= '</th>
						<td>';
					switch($o['type']) {
						case 'checkbox':
							$out .= $this->show_checkbox($oname, $this->options->get($oname), $o['caption']);
							break;
						case 'dropdown':
							$out .= $this->show_dropdown($oname, $this->options->get($oname), $o['caption']);
							break;
						case 'radio':
							$out .= $this->show_radio($oname, $this->options->get($oname), $o['caption']);
							break;
						case 'text':
							$out .= $this->show_text($oname, $this->options->get($oname));
							break;
						case 'textarea':
							$out .= $this->show_textarea($oname, $this->options->get($oname));
							break;
						case 'file-upload':
							$out .= $this->show_file_upload($oname, $o['maxsize']);
					}
					$out .= '
						</td>
						<td class="description">'.$o['desc'].'</td>
					</tr>';
				}
			}
		}
		$out .= '
		</table>
		</div>';
		return $out;
	}
	public function show_checkbox($name, $value, $caption, $disabled=false) {
		if($name=="el_feed_category"){
			$out="";
			$eventlistCat=$this->get_option_categories();
			if(is_array ($eventlistCat)){
				$eventlistCatSelect=$this->options->get($name);
				$this->eventlistSksort($eventlistCat,"name",true);
				foreach($eventlistCat as $key=>$value){
					$eventlistChecked="";
					if(isset($eventlistCatSelect[$value['slug']]) && $eventlistCatSelect[$value['slug']]){$eventlistChecked=' checked="checked"';}
					$out .= '<label for="el_feed_category['.$value['slug'].']"><input name="el_feed_category['.$value['slug'].']" type="checkbox" id="el_feed_category['.$value['slug'].']" value="1"'.$eventlistChecked.'/>'.$value['name'].'</label><br>';
				}
			}else{
				$out='No categories found';
			}
			return $out;
		}else{
			$out = '
								<label for="'.$name.'">
									<input name="'.$name.'" type="checkbox" id="'.$name.'" value="1"';
			if($value == 1) {
				$out .= ' checked="checked"';
			}
			$out .= $this->get_disabled_text($disabled).' />
									'.$caption.'
								</label>';
			return $out;
		}
	}
	public function eventlistSksort(&$array, $subkey="id", $sort_ascending=false) {
    if (count($array)) $temp_array[key($array)] = array_shift($array);
    foreach($array as $key => $val){
      $offset = 0;
      $found = false;
      foreach($temp_array as $tmp_key => $tmp_val){
        if(!$found and strtolower($val[$subkey]) > strtolower($tmp_val[$subkey])){
          $temp_array = array_merge((array)array_slice($temp_array,0,$offset),array($key => $val),array_slice($temp_array,$offset));
          $found = true;
        }
        $offset++;
      }
      if(!$found) $temp_array = array_merge($temp_array, array($key => $val));
    }
    if ($sort_ascending) $array = array_reverse($temp_array);
    else $array = $temp_array;
	}
	public function show_dropdown($name, $selected, $value_array, $class_array=null, $disabled=false) {
		$out = '
							<select id="'.$name.'" name="'.$name.'"'.$this->get_disabled_text($disabled).'>';
		foreach($value_array as $key => $value) {
			$class_text = isset($class_array[$key]) ? 'class="'.$class_array[$key].'" ' : '';
			$selected_text = $selected===$key ? 'selected ' : '';
			$out .= '
								<option '.$class_text.$selected_text.'value="'.$key.'">'.$value.'</option>';
		}
		$out .= '
							</select>';
		return $out;
	}

	public function show_radio($name, $selected, $value_array, $disabled=false) {
		$out = '
							<fieldset>';
		foreach($value_array as $key => $value) {
			$checked = ($selected === $key) ? 'checked="checked" ' : '';
			$out .= '
								<label title="'.$value.'">
									<input type="radio" '.$checked.'value="'.$key.'" name="'.$name.'">
									<span>'.$value.'</span>
								</label>
								<br />';
		}
		$out .= '
							</fieldset>';
		return $out;
	}

	public function show_text($name, $value, $disabled=false) {
		if($name=="el_color_button1" || $name=="el_color_button2" || $name=="el_color_button3" || $name=="el_color_button4" || $name=="el_color_button5"){
			$this->elButtonReady=true;
			$elDateColor1=$this->options->get("el_color_button1");
			$elDateColor2=$this->options->get("el_color_button2");
			$elDateColor3=$this->options->get("el_color_button3");
			$elDateColor4=$this->options->get("el_color_button4");
			$elDateColor5=$this->options->get("el_color_button5");
			$out='<div class="elDateBox">
						'.$this->show_text_date(1,$elDateColor1).$this->show_text_date(2,$elDateColor2).$this->show_text_date(3,$elDateColor3).$this->show_text_date(4,$elDateColor4).$this->show_text_date(5,$elDateColor5).'
						</div>
						'.$this->show_text_input(1,$elDateColor1,$disabled=false).$this->show_text_input(2,$elDateColor2,$disabled=false).$this->show_text_input(3,$elDateColor3,$disabled=false).$this->show_text_input(4,$elDateColor4,$disabled=false).$this->show_text_input(5,$elDateColor5,$disabled=false);
		}else{
			$out='<input name="'.$name.'" type="text" id="'.$name.'" value="'.$value.'"'.$this->get_disabled_text($disabled).' class="eventlistInputWidth"/>';
		}
		return $out;
	}
	public function show_text_date($elColorID,$elDateColor){
		return '<div class="start-date elMarginRight" id="el_color_button'.$elColorID.'box" style="background-color:#'.$elDateColor.';">
				<div class="event-weekday">'.mysql2date('D',date('d')).'</div>
				<div class="event-day">'.mysql2date('d',date('d')).'</div>
				<div class="event-month">'.mysql2date('M',date('m')).'</div>
				<div class="event-year">'.mysql2date('Y',date('y')).'</div>
			</div>';
	}
	public function show_text_input($elColorID,$elDateColor, $disabled=false) {
		return '<input name="el_color_button'.$elColorID.'" type="text" id="el_color_button'.$elColorID.'" class="el_color_button jscolor {onFineChange:\'update(this)\'}" value="'.$elDateColor.'"'.$this->get_disabled_text($disabled).'>';
	}
	public function show_textarea($name, $value, $disabled=false) {
		$out = '
							<textarea name="'.$name.'" id="'.$name.'" rows="5" class="large-text code"'.$this->get_disabled_text($disabled).'>'.$value.'</textarea>';
		return $out;
	}

	public function show_file_upload($name, $max_size, $disabled=false) {
		$out = '
							<input name="'.$name.'" type="file" maxlength="'.$max_size.'">';
		return $out;
	}

	public function get_disabled_text($disabled=false) {
		return $disabled ? ' disabled="disabled"' : '';
	}
	public function get_option_categories() {
		$this->options = &EL_Options::get_instance();
		$cat_array = $this->options->get('el_categories');
		return $cat_array;
	} 
}
?>